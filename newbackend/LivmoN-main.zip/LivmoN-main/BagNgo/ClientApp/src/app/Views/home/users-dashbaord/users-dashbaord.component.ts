import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-dashbaord',
  templateUrl: './users-dashbaord.component.html',
  styleUrls: ['./users-dashbaord.component.css']
})
export class UsersDashbaordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
