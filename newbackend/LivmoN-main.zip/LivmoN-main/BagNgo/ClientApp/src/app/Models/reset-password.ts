
export interface ResetPassword {
  password: string;
  confirmPassword: string;
  email: string;
  token: string;
}
