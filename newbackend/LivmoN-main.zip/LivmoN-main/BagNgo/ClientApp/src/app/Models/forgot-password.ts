export interface forgetPassword {
  email: string;
  clientURI: string;
}
